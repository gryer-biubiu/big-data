# # 定义超链接栏的数据
# links_data = [
#     {"text": "Python帮助文档", "url": "https://www.cnpython.com"},
#     {"text": "爬虫代码自动生成", "url": "https://curlconverter.com"},
#     {"text": "VPN代理", "url": "https://www.xmkyun.com/user"},
#     {"text": "CSDN博客", "url": "https://blog.csdn.net/"},
#     {"text": "pyecharts", "url": "https://pyecharts.org/#/zh-cn/datasets"},
#     # 添加更多链接
# ]
#
# # 将数据写入txt文件
# # 将数据写入txt文件，指定编码为UTF-8
# with open("../user_txt/links_data.txt", "w", encoding="utf-8") as file:
#     for link in links_data:
#         file.write(f"{link['text']}: {link['url']}\n")


def read_links_data():
    links_data = []
    with open("../user_txt/links_data.txt", "r",encoding="utf-8") as file:
        # print(file)
        for line in file:
            print(line)
            parts = line.split(',')
            print(parts)
            if len(parts) == 2:
                text = parts[0].strip()
                print(text)
                url = parts[1].strip()
                links_data.append({"text": text, "url": url})
    return links_data

links_data = read_links_data()
print(links_data)